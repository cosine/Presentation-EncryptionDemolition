#!/usr/bin/env ruby
require "openssl"

class String
  # "41" --> "A"
  def ynhex
    [self].pack("H*")
  end

  # "A" --> "41"
  def hexy
    unpack("H*").first
  end
end

attempted = ARGV.join.gsub(/\s+/, "").ynhex
answer_hash = "44f33abbfe2723f0ddf8203bd2db2026bb188dff2f2661fb70272125934b6a48414f7adee3213a9442092a02ce5ef595567d4e136cc6ec5d324d30d982b4b82b"
if answer_hash == OpenSSL::Digest::SHA512.new.update(attempted).hexdigest
  puts "Winner!"
else
  puts "Keep trying!"
end
